﻿namespace Marco_mvc_RM550128.Models
{
    public class User
    {

        public int id { get; set; }

        public string name { get; set; } = "marco";

        public string email { get; set; } = "marco@gmial.com";
    }
}
